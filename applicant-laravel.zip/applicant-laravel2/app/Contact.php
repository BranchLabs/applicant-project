<?php
namespace App;
//we are extending our own little ORM instead of eloquent just for this exersise
class Contact extends AbstractModel
{
    protected $_table = "contacts";
    protected $_pk	  = "id";
}