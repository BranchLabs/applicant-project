<?php

namespace App\Http\Controllers;

use App\Contact;
use App\Http\Controllers\Controller;

class ContactController extends Controller
{
    /**
     * Show the profile for the given user.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        //bypass eloquent and use our own ORM
        $contact = New Contact();
        $arr = $contact->load($id)->getData();
        return view('contact', $arr);
    }
}